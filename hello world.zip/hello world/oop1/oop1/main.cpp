//
//  main.cpp
//  oop1
//
//  Created by 张英奇 on 2020/9/13.
//  Copyright © 2020 张英奇. All rights reserved.
//

#include <iostream>
#include <cmath>
using namespace std;

const double pi = 3.1415926535898;
class comp
{
  public:
    double a, b;
    void input()
    {
        cout << "\nreal: ";
        cin >> a;
        cout << "\nimage: ";
        cin >> b;
    }
    void output() { cout << a << "+" << b << "i" << endl; }
    void gonge() { b = -b; }
    double abs() { return sqrt(a * a + b * b); }
};
comp add(comp a, comp b)
{
    comp r;
    r.a = a.a + b.a;
    r.b = a.b + b.b;
    return r;
}
comp sub(comp a, comp b)
{
    b.a = -b.a;
    b.b = -b.b;
    return add(a, b);
}
comp mul(comp a, comp b)
{
    comp r;
    r.a = a.a * b.a - a.b * b.b;
    r.b = a.a * b.b + a.b * b.a;
    return r;
}
comp div(comp a, comp b)
{
    if (b.a != 0 || b.b != 0)
    {
        b.gonge();
        comp r = mul(a, b);
        double m = b.abs();
        r.a /= m;
        r.b /= m;
        return r;
    }
    return b;
}
comp cexp(comp z)
{
    comp r, e;
    r.a = exp(z.a);
    r.b = 0;
    e.a = cos(z.b);
    e.b = sin(z.b);
    r = mul(r, e);
    return r;
}
comp cln(comp z)
{
    comp r;
    r.a = log(z.abs());
    if (r.a == 0)
    {
        if (r.b > 0)
            r.b = pi / 2.0;
        if (r.b < 0)
            r.b = -pi / 2.0;
    }
    else
    {
        if (r.b >= 0)
        {
            r.b = atan(z.b / z.a);
        }
        else
        {
            r.b = 2 * pi - atan(z.b / z.a);
        }
    }
    return r;
}
comp cpow(comp a, comp b) { return cexp(mul(cln(a), b)); }
int main(int argc, const char *argv[])
{
    int n, i;
    comp r, j;
    r.a = 0;
    r.b = 0;
    cout << "number: ";
    cin >> n;
    for (i = 0; i < n; i++)
    {
        j.input();
        r = add(r, j);
    }
    cout << "\nresult: ";
    r.output();
    return 0;
}
