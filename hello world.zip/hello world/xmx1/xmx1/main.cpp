//
//  main.cpp
//  xmx1
//
//  Created by 张英奇 on 2020/9/14.
//  Copyright © 2020 张英奇. All rights reserved.
//

#include <stdio.h>
#include <math.h>

int main(int argc, const char *argv[])
{
    const double a = 3.1415926536 / 4;
    printf("%.5f\n", sin(a) * sin(a) - sin(a) * cos(a) - cos(a) * cos(a));
    return 0;
}
