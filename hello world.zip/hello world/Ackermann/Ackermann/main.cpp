//
//  main.cpp
//  Ackermann
//
//  Created by 张英奇 on 2020/10/7.
//

#include <iostream>
using namespace std;
unsigned Ack(unsigned x, unsigned y)
{
    if (x == 0)
    {
        return (y + 1);
    }
    if (y == 0)
    {
        return Ack(x - 1, 1);
    }
    return Ack(x - 1, Ack(x, y - 1));
}
int main(int argc, const char *argv[])
{
    unsigned a, b;
    cin >> a >> b;
    cout << "\n\n" << Ack(a, b) << endl;
    return 0;
}
