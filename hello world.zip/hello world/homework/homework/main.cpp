#include <fstream>
#include <iomanip>
using namespace std;

float min(float mark[], int n)
{
    float m =mark[0];
    for (int i = 0; i < n;i++)
        if(mark[i]<m)
            m = mark[i];
    return m;
}
float max(float mark[], int n)
{
    float m = mark[0];
    for (int i = 0; i < n;i++)
        if(mark[i]>m)
            m = mark[i];
    return m;
}
float ave(float mark[], int n)
{
    float sum = 0;
    for (int i = 0; i < n; i++)
        sum += mark[i];
    return sum / n;
}
int main()
{
    int n = 0;
    float *data[5];
    ifstream in("input.txt");
    in >> n;
    if(!n)
        return 0;
    for (int i = 0; i < 5; i++)
        data[i] = new float[n]{};
    for (int i = 0; i < n; i++)
    {
        string no;
        in >> no;
        for (int j = 0; j < 4; j++)
        {
            in >> data[j][i];
            data[4][i] += data[j][i];
        }
    }
    in.close();
    ofstream out("output.txt");
    for (int i = 0; i < 5; i++)
    {
        out << fixed << setprecision(3) << max(data[i], n) << ' '
            << min(data[i], n) << ' '
            << ave(data[i], n) << endl;
    }
    out.close();
    return 0;
}
