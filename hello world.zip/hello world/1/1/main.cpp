//
//  main.cpp
//  1
//
//  Created by 张英奇 on 2020/9/6.
//  Copyright © 2020 张英奇. All rights reserved.
//

#include <iostream>
#include <cmath>
using namespace std;
double f(double x) { return exp(-x * x / 2) / sqrt(2 * 3.1415926535898); }
int main(int argc, const char *argv[])
{
    int i;
    const int m = 1048575;
    double a, b, d, S = 0.0;
    cout << endl;
    cin >> a >> b;
    d = (b - a) / m;
    for (i = 1; i < m; i++)
    {
        S += d * f(a + i * d);
    }
    S += d * (f(a) + f(b)) / 2;
    cout << S << endl;
    return 0;
}
