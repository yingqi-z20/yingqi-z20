//
//  main.cpp
//  xmx2
//
//  Created by 张英奇 on 2020/9/14.
//  Copyright © 2020 张英奇. All rights reserved.
//

#include <iostream>
using namespace std;
int main(int argc, const char *argv[])
{
    int w, i;
    cin >> w;
    for (i = 0; i < w; i++)
    {
    }
    return 0;
}
