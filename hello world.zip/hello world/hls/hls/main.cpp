//
//  main.cpp
//  hls
//
//  Created by 张英奇 on 2020/9/6.
//  Copyright © 2020 张英奇. All rights reserved.
//

#include <iostream>
using namespace std;

int n;
long D[64][64];
long det = 0;
long a[64];
int fun();
long me(int n, int m)
{
    int p;
    long A = 1;
    for (p = 0; p < m; p++)
    {
        A = A * n;
    }
    return A;
}
int swap(long *x, long *y)
{
    if (*x <= *y)
    {
        return 1;
    }
    else
    {
        long temp = *x;
        *x = *y;
        *y = temp;
        return 0;
    }
}
int nxs(int n, long a[256])
{
    unsigned j, s, p = 0, t = 0;
    while (p != 1)
    {
        for (j = 0, p = 1; j < n - 1; j++)
        {
            s = swap(&a[j], &a[j + 1]);
            p = p * s;
            t = t ^ (s ^ 1);
        }
    }
    return t;
}
int input()
{
    int i, j;
    cout << "\n 阶数=";
    cin >> n;
    if (n <= 1)
    {
        if (n == 1)
        {
            cin >> i;
            cout << i << endl;
            fun();
            return 0;
        }
        else
        {
            return 0;
        }
    }
    else
    {
        for (i = 0; i < n; i++)
        {
            for (j = 0; j < n; j++)
            {
                cin >> D[i][j];
            }
        }
        return 1;
    }
}
int equ(long x, long y)
{
    if (x == y)
    {
        return 0;
    }
    else
    {
        return 1;
    }
}
int arr(long i)
{
    int k, l, r = 1;
    long m;
    for (k = n - 1; k >= 0; k = k - 1)
    {
        m = me(n, k);
        a[k] = i / m;
        i = i % m;
    }
    for (l = 1; l < n; l++)
    {
        for (k = 0; k < n - l; k++)
        {
            r = r * equ(a[k], a[k + l]);
        }
    }
    return r;
}
int calculate()
{
    det = 0;
    int j, k, t;
    long i, N, T = 1;
    N = me(n, n);
    for (i = 0; i < N; i++)
    {
        j = arr(i);
        if (j != 0)
        {
            T = 1;
            for (k = 0; k < n; k++)
            {
                T = T * D[k][a[k]];
            }
            t = nxs(n, a);
            T = T * (1 - 2 * t);
            det = det + T;
        }
    }
    return 0;
}
int fun()
{
    int e;
    e = input();
    if (e)
    {
        calculate();
        cout << "\n\n" << det << endl;
        fun();
    }
    return 0;
}
int main()
{
    fun();
    return 0;
}
