//
//  main.cpp
//  matpow
//
//  Created by 张英奇 on 2020/9/26.
//

#include <iostream>
using namespace std;
int n = 0, p = 0;
long double D[256][256][256] = {0};
bool input()
{
    int i, j;
    n = 0;
    p = 0;
    cout << "\n 次数=";
    cin >> p;
    cout << "\n 阶数=";
    cin >> n;
    if (n < 1 || p < 1)
    {
        return 1;
    }
    else
    {
        for (i = 0; i < n; i++)
        {
            for (j = 0; j < n; j++)
            {
                cin >> D[i][j][0];
            }
        }
        return 0;
    }
}
void calculate(int t)
{
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            D[i][j][t + 1] = 0;
            for (int k = 0; k < n; k++)
            {
                D[i][j][t + 1] += D[i][k][t] * D[k][j][0];
            }
        }
    }
}
int fun()
{
    bool b = input();
    if (b)
        return 0;
    for (int i = 0; i < p; i++)
    {
        calculate(i);
    }
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cout << D[i][j][p - 1] << "    ";
        }
        cout << endl;
    }
    fun();
    return 0;
}
int main(int argc, const char *argv[])
{
    fun();
    return 0;
}
