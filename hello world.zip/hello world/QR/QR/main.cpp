//
//  main.cpp
//  QR
//
//  Created by 张英奇 on 2020/11/1.
//

#include <iostream>
#include <cmath>
using namespace std;

int n = 0;
long double A[256][256] = {0};
long double Q[256][256] = {0};
long double R[256][256] = {0};
bool input()
{
    int i, j;
    n = 0;
    cout << "\n 阶数=";
    cin >> n;
    if (n < 1)
    {
        return 1;
    }
    else
    {
        for (i = 0; i < n; i++)
        {
            for (j = 0; j < n; j++)
            {
                cin >> A[i][j];
            }
        }
        return 0;
    }
}
void QR()
{
    for (int i = 0; i < n; i++)
    {
        R[i][i] = 1;
        for (int k = 0; k < n; k++)
        {
            Q[k][i] = A[k][i];
        }
        for (int j = 0; j < i; j++)
        {
            long double l = 0, qa = 0;
            for (int k = 0; k < n; k++)
            {
                l += Q[k][j] * Q[k][j];
            }
            for (int k = 0; k < n; k++)
            {
                qa += Q[k][j] * A[k][i];
            }
            R[j][i] = qa / l;
            for (int k = 0; k < n; k++)
            {
                Q[k][i] -= R[j][i] * Q[k][j];
            }
        }
    }
    for (int i = 0; i < n; i++)
    {
        long double m = 0;
        for (int j = 0; j < n; j++)
        {
            m += Q[j][i] * Q[j][i];
        }
        m = sqrt(m);
        for (int j = 0; j < n; j++)
        {
            Q[j][i] /= m;
            R[i][j] *= m;
        }
    }
}
int fun()
{
    bool b = input();
    if (b)
        return 0;
    QR();
    cout << "Q:" << endl;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cout << Q[i][j] << "    ";
        }
        cout << endl;
    }
    cout << "R:" << endl;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cout << R[i][j] << "    ";
        }
        cout << endl;
    }
    fun();
    return 0;
}
int main(int argc, const char *argv[])
{
    fun();
    return 0;
}
