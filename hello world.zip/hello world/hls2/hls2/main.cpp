//
//  main.cpp
//  hls2
//
//  Created by 张英奇 on 2020/9/17.
//  Copyright © 2020 张英奇. All rights reserved.
//

#include <iostream>

using namespace std;

int n = 0;
long double D[4096] = {0};
long double det = 0;
bool input()
{
    int i, j;
    n = 0;
    cout << "\n 阶数=";
    cin >> n;
    if (n < 1)
    {
        return 0;
    }
    else
    {
        for (i = 0; i < n; i++)
        {
            for (j = 0; j < n; j++)
            {
                cin >> D[i * n + j];
            }
        }
        return 1;
    }
}
void output() { cout << "\n\n" << det << endl; }
long double calculate(int m, long double a[])
{
    if (m == 1)
    {
        return a[0];
    }
    else
    {
        int i, j, k;
        long double r = 0;
        long double d[4096];
        for (k = 0; k < m; k++)
        {
            for (i = m, j = 0; j < (m - 1) * (m - 1); i++)
            {
                if (i % m != k)
                {
                    d[j] = a[i];
                    j++;
                }
            }
            r += a[k] * (1 - 2 * (k % 2)) * calculate(m - 1, d);
        }
        return r;
    }
}
int fun()
{
    bool c = input();
    if (c)
    {
        det = calculate(n, D);
        cout << "\n\n" << det << endl;
        fun();
    }
    return 0;
}
int main(int argc, const char *argv[])
{
    fun();
    return 0;
}
