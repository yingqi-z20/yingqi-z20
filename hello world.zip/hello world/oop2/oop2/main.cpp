//
//  main.cpp
//  oop2
//
//  Created by 张英奇 on 2020/9/18.
//

#include <iostream>

using namespace std;

int main(int argc, const char *argv[])
{
    // insert code here...
    cout << "Hello, World!\n";
    return 0;
}
