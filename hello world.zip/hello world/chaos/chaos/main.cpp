//
//  main.cpp
//  chaos
//
//  Created by 张英奇 on 2020/9/20.
//

#include <iostream>

using namespace std;
int main()
{
    double a, c;
    cin >> a >> c;
    for (int i = 1; i < 256; i++)
    {
        c = a * c * (1 - c);
        cout << c << endl;
    }
    main();
    return 0;
}
