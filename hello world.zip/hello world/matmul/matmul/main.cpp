//
//  main.cpp
//  matmul
//
//  Created by 张英奇 on 2020/9/23.
//

#include <iostream>
using namespace std;
int n, m, p;
long double A[256][256] = {0}, B[256][256] = {0}, C[256][256] = {0};
bool input()
{
    n = 0;
    m = 0;
    p = 0;
    cin >> n >> p >> m;
    if (!(n * m * p))
        return 1;
    cout << "矩阵A:" << endl;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < p; j++)
        {
            cin >> A[i][j];
        }
    }
    cout << "矩阵B:" << endl;
    for (int i = 0; i < p; i++)
    {
        for (int j = 0; j < m; j++)
        {
            cin >> B[i][j];
        }
    }
    return 0;
}
void calculate()
{
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            C[i][j] = 0;
            for (int k = 0; k < p; k++)
            {
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }
}
int fun()
{
    bool b = input();
    if (b)
        return 0;
    calculate();
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            cout << C[i][j] << "    ";
        }
        cout << endl;
    }
    fun();
    return 0;
}
int main(int argc, const char *argv[])
{
    fun();
    return 0;
}
