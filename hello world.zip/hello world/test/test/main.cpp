
#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    fstream x;
    char a[] = "Tsinghua";
    cout << a << '\n'
         << sizeof(a) << '\n'
         << (int *)a << '\n'
         << (int *)&a[0] << '\n'
         << (int *)&a[1] << '\n';
    return 0;
}
