//
//  main.cpp
//  njz
//
//  Created by 张英奇 on 2020/10/8.
//

#include <iostream>

using namespace std;

int n = 0;
long double D[1024] = {0};
long double D_bs[1024] = {0};
long double det = 0;
bool input()
{
    int i, j;
    n = 0;
    cout << "\n\n 阶数=";
    cin >> n;
    if (n <= 1)
    {
        return 0;
    }
    else
    {
        for (i = 0; i < n; i++)
        {
            for (j = 0; j < n; j++)
            {
                cin >> D[j * n + i];
            }
        }
        return 1;
    }
}
void output()
{
    cout << "行列式的值为:\n" << det << endl << "伴随阵为:\n";
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cout << D_bs[i * n + j] << "    ";
        }
        cout << "\n";
    }
    if (det != 0)
    {
        cout << "逆矩阵为:\n";
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                cout << D_bs[i * n + j] / det << "    ";
            }
            cout << "\n";
        }
    }
    else
    {
        cout << "\n逆矩阵不存在!\n";
    }
}
long double calculate(int m, long double a[])
{
    if (m == 1)
    {
        return a[0];
    }
    else
    {
        int i, j, k;
        long double r = 0;
        long double d[1024] = {0};
        for (k = 0; k < m; k++)
        {
            for (i = m, j = 0; j < (m - 1) * (m - 1); i++)
            {
                if (i % m != k)
                {
                    d[j] = a[i];
                    j++;
                }
            }
            r += a[k] * (1 - 2 * (k % 2)) * calculate(m - 1, d);
        }
        return r;
    }
}
int fun()
{
    bool c = input();
    if (c)
    {
        det = calculate(n, D);
        for (int i = 0, bs = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                if (j == 0)
                {
                    cout << "\n";
                }
                long double d[1024] = {0};
                for (int k = 0, l = 0; k < n * n; k++)
                {
                    if (k % n != j && k / n != i)
                    {
                        d[l] = D[k];
                        l++;
                    }
                }
                D_bs[bs] = (1 - 2 * ((i + j) % 2)) * calculate(n - 1, d);
                bs++;
            }
        }
        output();
        fun();
    }
    return 0;
}
int main(int argc, const char *argv[])
{
    fun();
    return 0;
}
