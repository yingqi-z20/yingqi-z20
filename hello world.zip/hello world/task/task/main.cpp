//
//  main.cpp
//  task
//
//  Created by 张英奇 on 2020/10/28.
//

#include <iostream>
using namespace std;

struct monkey
{
    int num;      // 猴子号
    monkey *next; // monkey结构指针
} * head, *tail;

void create(int nn);
void select(int mm);

int main()
{
    int n, m;
    head = NULL; // 初始化head为NULL，空指针，值为0
    cout << "请输入猴子数\n";
    cin >> n; // 输入待插入结点数据
    cout << "请输入间隔m\n";
    cin >> m;
    create(n); // 调用函数create, 建立循环链表
    select(m); // 调用函数select，找出剩下的猴子
    cout << "猴王是" << head->num << "号\n";
    return 0;
}

void create(int nn)
{
    monkey *p, *q;

    p = new monkey;
    p->num = 1;
    p->next = NULL; /// NULL是空指针值，值为0

    head = p; // 链表头指针head赋值为p
    q = p;    // 指针q赋值为p
    for (int i = 2; i <= nn; i++)
    {
        p = new monkey;
        p->num = i;
        p->next = NULL; // 链表尾部指向空
        q->next = p;    // 将p结点加到链表尾部
        q = p;          // 让q指向链表尾部结点
    }
    tail = q;
    tail->next = head; // 链表尾部指向链表头
}

// mm表示结点删除间隔
void select(int mm)
{
    int x = 0;
    monkey *p, *q;

    q = tail; // q 指向循环链表尾部
    do
    {
        p = q->next; // p赋值为q相邻的下一个结点
        x++;
        if (x % mm == 0)
        { // 表示是否跳过了指定的间隔
            cout << "被删掉的猴子号为" << p->num << "号\n";
            q->next = p->next; // 删除此结点
            delete p;
            p = NULL;
        }
        else
            q = p;          // q指向相邻的下一个结点p
    } while (q != q->next); // 剩余结点数不为1，则继续循环
    head = q; // head指向结点q，q为链表中剩余的一个结点
}
