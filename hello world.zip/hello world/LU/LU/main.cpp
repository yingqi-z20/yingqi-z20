//
//  main.cpp
//  LU
//
//  Created by 张英奇 on 2020/10/17.
//

#include <iostream>
using namespace std;

int n = 0;
long double M[256][256] = {0};
bool input()
{
    int i, j;
    n = 0;
    cout << "\n 阶数=";
    cin >> n;
    if (n < 1)
    {
        return 1;
    }
    else
    {
        for (i = 0; i < n; i++)
        {
            for (j = 0; j < n; j++)
            {
                cin >> M[i][j];
            }
        }
        return 0;
    }
}
void calculate(int m)
{
    for (int i = m + 1; i < n; i++)
    {
        M[i][m] = M[i][m] / M[m][m];
        for (int j = m + 1; j < n; j++)
        {
            M[i][j] -= M[i][m] * M[m][j];
        }
    }
}
void LU()
{
    for (int i = 0; i < n; i++)
    {
        calculate(i);
    }
}
int fun()
{
    bool b = input();
    if (b)
        return 0;
    LU();
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cout << M[i][j] << "    ";
        }
        cout << endl;
    }
    fun();
    return 0;
}
int main(int argc, const char *argv[])
{
    fun();
    return 0;
}
