//
//  main.cpp
//  combine
//
//  Created by 张英奇 on 2020/10/5.
//

#include <iostream>

int main(int argc, const char *argv[])
{
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
