//
//  rational.h
//  hls3
//
//  Created by 张英奇 on 2020/10/26.
//

#ifndef rational_h
#define rational_h

class rn
{
  private:
    int p = 0, q = 1;
    void sim()
    {
        for (int i = 2; i <= p && i <= q;)
        {
            if (p % i == 0 && q % i == 0)
            {
                p /= i;
                q /= i;
            }
            else
            {
                i++;
            }
        }
    }

  public:
    bool input(int a, int b)
    {
        if (b == 0)
            return 0;
        p = a;
        q = b;
        sim();
        return 1;
    }
    friend rn operator+(rn a, rn b);
    friend rn operator-(rn a, rn b);
    friend rn operator*(rn a, rn b);
    friend rn operator/(rn a, rn b);
};
rn operator+(rn a, rn b)
{
    rn r;
    r.input(a.p * b.q + a.q * b.p, a.q * b.q);
    return r;
}
rn operator-(rn a, rn b)
{
    rn r;
    r.input(a.p * b.q - a.q * b.p, a.q * b.q);
    return r;
}
rn operator*(rn a, rn b)
{
    rn r;
    r.input(a.p * b.p, a.q * b.q);
    return r;
}
rn operator/(rn a, rn b)
{
    rn r;
    r.input(a.p * b.q, a.q * b.p);
    return r;
}

#endif /* rational_h */
