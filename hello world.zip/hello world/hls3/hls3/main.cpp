//
//  main.cpp
//  hls3
//
//  Created by 张英奇 on 2020/10/17.
//

#include <iostream>
#include "rational.h"
using namespace std;

extern int n;
extern long double M[256][256];
extern void LU();
extern bool input();
long double det = 0;
int fun()
{
    bool b = input();
    if (b)
        return 0;
    LU();
    det = 1;
    for (int i = 0; i < n; i++)
    {
        det *= M[i][i];
    }
    cout << det;
    fun();
    return 0;
}
int main(int argc, const char *argv[])
{
    fun();
    return 0;
}
