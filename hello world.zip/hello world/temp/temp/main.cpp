#include <iostream>
int main()
{
    double a = 0.5;
    int b = 1;
    double *c = &a;
    *c = 1.2;
    std::cout << sizeof(short) << "\n"
              << sizeof(int) << "\n"
              << sizeof(long int) << "\n"
              << sizeof(long long int) << "\n"
              << sizeof(float) << "\n"
              << sizeof(double) << "\n"
              << sizeof(long double) << "\n"
              << sizeof(char) << "\n"
              << sizeof(bool) << "\n"
              << sizeof(double *) << "\n"
              << sizeof(a) << "\n"
              << sizeof(b) << "\n"
              << sizeof(c) << "\n";
    return 0;
}
